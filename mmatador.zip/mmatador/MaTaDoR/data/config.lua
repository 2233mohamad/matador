# کانال ایلیا سورس ✲ به کانال ما برای دریافت سورس های بیشتر سر بزنید :) @Source_Eliya
do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "Administrative",
    "Fun",
    "GroupManager",
    "Msg-Checks",
    "SetUp-Plugins",
    "Core",
    "Helper-Api",
    "Help-Api",
    "Helper-Top",
    "test",
    "Mutetime"
  },
  enabled_plugins_api = {
    "Helper-Api",
    "Helper-Top",
    "Help-Api"
  },
  sudo_users = {
    464555636,
    605046353,
    679719822,
    521307846,
    97476012
  }
}
return _
end